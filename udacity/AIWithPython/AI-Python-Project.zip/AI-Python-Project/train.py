#Imports
import argparse

import matplotlib.pyplot as plt
import numpy as np
import PIL
from PIL import Image

import torch
from torch import nn
from torch import optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
import torch.nn.functional as F
from torchvision import datasets, transforms, models

import os
import time
import copy
import json
import math

import train_helper

parser = argparse.ArgumentParser(description='Training a flower image classifier')

# Required argumant
parser.add_argument('data_directory', action='store', help='This is the directory where your training, validation and test datasets are')

# Optional argumant
parser.add_argument('--save_dir', action='store', dest='save_dir', default='.',
                    help='This is the directory where you save your checkpoints')
parser.add_argument('--arch', action='store', dest='arch', default='densenet', choices=('densenet', 'vgg'),
                    help='Choose architecture of densenet or vgg')
parser.add_argument('--learning_rate', action='store', dest='learning_rate', default=0.001, type=float, 
                    help='Define learning rate.')
parser.add_argument('--hidden_units', action='store', dest='hidden_units', default=1104, type=int, 
                    help='Define hidden units')
parser.add_argument('--epochs', action='store', dest='epochs', default=5, type=int, 
                    help='Define epochs')
parser.add_argument('--gpu', action='store_true', default=False, dest='gpu',
                    help='Use GPU for training')

args = parser.parse_args()

print(args)

dataloaders, image_datasets = train_helper.get_dataloaders(args.data_directory)
dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'valid', 'test']}
# Test the dataloaders
images, labels = next(iter(dataloaders['train']))
print(images.shape)
print(labels)

# set the device
if (args.gpu and torch.cuda.is_available()):
    device = torch.device("cuda:0")
else:
    device = torch.device("cpu")
    
# Build the model:
hidden_layers = []
hidden_layers.append(args.hidden_units)
model, criterion, optimizer, scheduler = train_helper.get_model(args.arch, hidden_layers, args.learning_rate)

model.to(device)

model
model = train_helper.train_model(dataloaders, dataset_sizes, device, model, criterion, optimizer, scheduler, args.epochs)
print('Training is done')

# TODO: Testing your network
model.eval()
accuracy = 0
for inputs, labels in dataloaders['test']:
    inputs, labels = inputs.to(device), labels.to(device)
    outputs = model(inputs)
    
    # Class with the highest probability is our predicted class
    equality = (labels.data == outputs.max(1)[1])
    # Accuracy is number of correct predictions divided by all predictions
    accuracy += equality.type_as(torch.FloatTensor()).mean()
    
print("Test accuracy: {:.3f}".format(accuracy/len(dataloaders['test'])))

# TODO: Save the checkpoint 
model.class_to_idx = image_datasets['train'].class_to_idx

if args.arch == 'densenet':
    checkpoint = {'input_size': 2208, # for densenet
              'output_size': 102,
              'epochs': args.epochs,
              'batch_size': 64,
              'model': models.densenet161(pretrained=True),
              'classifier': model.classifier,
              'scheduler': scheduler,
              'optimizer': optimizer.state_dict(),
              'state_dict': model.state_dict(),
              'class_to_idx': model.class_to_idx
                 }
    torch.save(checkpoint, 'densenetcheckpoint.pth')
elif args.arch == 'vgg':
    checkpoint = {'input_size': 25088, # for vgg
              'output_size': 102,
              'epochs': args.epochs,
              'batch_size': 64,
              'model': models.vgg19(pretrained=True),
              'classifier': model.classifier,
              'scheduler': scheduler,
              'optimizer': optimizer.state_dict(),
              'state_dict': model.state_dict(),
              'class_to_idx': model.class_to_idx
             }
    torch.save(checkpoint, 'vggcheckpoint.pth')
else:
    print("Unknown model, please use densenet or vgg")

print("checkpoint saved!")