#Imports
import argparse

import matplotlib.pyplot as plt
import numpy as np
import PIL
from PIL import Image

import torch
from torch import nn
from torch import optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
import torch.nn.functional as F
from torchvision import datasets, transforms, models

import os
import time
import copy
import json
import math

import predict_helper

parser = argparse.ArgumentParser(description='Predict a flower image use a pre-trained flower image classifier')

# Required argumant
# image_path example: 'flowers/test/13/image_05745.jpg'
parser.add_argument('image_path', action='store', help='This is path to the image for prediction')
parser.add_argument('checkpoint', action='store', help='This is the checkpoint, choose densenetcheckpoint.pth or vggcheckpoint.pth')

# Optional argumant
parser.add_argument('--top_k', action='store', dest='top_k', default=3, type=int,
                    help='Return top K most likely classes')
parser.add_argument('--category_names', action='store', dest='category_names', default='cat_to_name.json',
                    help='Use a mapping of categories to real names')
parser.add_argument('--gpu', action='store_true', default=False, dest='gpu',
                    help='Use GPU for training')

args = parser.parse_args()
print(args)

with open(args.category_names, 'r') as f:
    cat_to_name = json.load(f)
    
#set the device
if (args.gpu and torch.cuda.is_available()):
    device = torch.device("cuda:0")
else:
    device = torch.device("cpu")
print(device)
    
#load the model
model, class_to_idx = predict_helper.load_checkpoint(args.checkpoint)
model
                                                     
# TODO: Display an image along with the top top_k classes
probs, classes = predict_helper.predict(args.image_path, device, model.to(device), topk=args.top_k)
print(probs)
print(classes)
class_names = list(model.class_to_idx.keys())
flower_names = [cat_to_name[class_names[e]] for e in classes]
print(flower_names)